#ifndef __I2C_H__
#define __I2C_H__
#include <xmc_gpio.h>
#include <xmc_i2c.h>



void i2cGPIOInit(void);
void i2cInit(void);
uint8_t i2cWaitStatusFlag(uint32_t StatusFlag);
uint8_t i2cWriteByte(uint8_t dev,uint8_t reg ,uint8_t data);
uint8_t i2cReadByte(uint8_t dev,uint8_t reg);
uint8_t i2cWriteBit(uint8_t dev,uint8_t reg,uint8_t bitn,uint8_t data);
uint8_t i2cWriteBits(uint8_t dev,uint8_t reg,uint8_t bitn,uint8_t len,uint8_t data);
//uint8_t i2cWriteBuf(uint8_t dev,uint8_t reg ,uint8_t *pbuf,uint8_t len);
uint8_t i2cReadBuf(uint8_t dev,uint8_t reg ,uint8_t *pbuf,uint8_t len);



#endif
