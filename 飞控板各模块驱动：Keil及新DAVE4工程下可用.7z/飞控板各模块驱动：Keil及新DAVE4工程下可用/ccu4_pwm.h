#ifndef __CCU4_PWM_H__
#define __CCU4_PWM_H__
#include <xmc_gpio.h>
#include <xmc_ccu4.h>


void CCU4_PWM_Init(void);
void CCU4_PWM_SetCompare(uint8_t channel,uint32_t val);
void CCU4_PWM_GPIO_Init(void);


#endif

