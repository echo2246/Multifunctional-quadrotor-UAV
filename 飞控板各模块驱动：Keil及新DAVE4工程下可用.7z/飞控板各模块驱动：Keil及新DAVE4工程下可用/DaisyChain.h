#ifndef _DAISYCHAIN_H
#define _DAISYCHAIN_H
#include <stdint.h>

#define START_MOTOR				10
#define STOP_MOTOR				11
#define SET_REF_SPEED			34

#define DAISY_BUFFER_SIZE		13
#define DAISY_MESSAGE_LENGTH 	3
#define DAISY_STOP_BYTE 		4


void daisyChainGPIOInit(void);
void daisyChainInit(void);
void daisyChainSendData(uint8_t command,uint16_t data1,uint16_t data2,uint16_t data3,uint16_t data4);
void daisyChainSetMotors(uint16_t motor1,uint16_t motor2,uint16_t motor3,uint16_t motor4);


#endif
