#include "DaisyChain.h"
#include <xmc_uart.h>
#include <xmc_gpio.h>


/*************************************************
*
*	ʹ��˵����
*		ʹ��ģ�飺����1ͨ��1->XMC_UART1_CH1
*			1.��ʼ����daisyChainInit();
*			2.�������ţ�daisyChainSetMotors();
*
*************************************************/

uint8_t DaisyTransmit[DAISY_BUFFER_SIZE]; /**< intern buffer for DaisyChain transmit data */

uint16_t speedval1 = 0;/**< Motor 1 speed parameter Range: 0-65535	 65535->Motorspeed=100% 0->Motorspeed=0% */
uint16_t speedval2 = 0;/**< Motor 2 speed parameter Range: 0-65535   65535->Motorspeed=100% 0->Motorspeed=0% */
uint16_t speedval3 = 0;/**< Motor 3 speed parameter Range: 0-65535   65535->Motorspeed=100% 0->Motorspeed=0% */
uint16_t speedval4 = 0;/**< Motor 4 speed parameter Range: 0-65535   65535->Motorspeed=100% 0->Motorspeed=0% */
/******************************
*
*	����ͨ�Ŵ���GPIO��ʼ��
*
*******************************/
void daisyChainGPIOInit(void)
{
	XMC_GPIO_CONFIG_t gpio_cfg;
	gpio_cfg.mode = XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT2;
	gpio_cfg.output_level = XMC_GPIO_OUTPUT_LEVEL_HIGH;
	gpio_cfg.output_strength = XMC_GPIO_OUTPUT_STRENGTH_STRONG_SOFT_EDGE;
	/* TX PIN */
	XMC_GPIO_Init(XMC_GPIO_PORT0,1,&gpio_cfg);
	gpio_cfg.mode = XMC_GPIO_MODE_INPUT_TRISTATE;
	/* RX PIN*/
	XMC_GPIO_Init(XMC_GPIO_PORT0,0,&gpio_cfg);
}

/*****************************
*
*	������ڳ�ʼ����FIFO����
*
*****************************/
void daisyChainInit(void)
{
	XMC_UART_CH_CONFIG_t uart_cfg;
	uart_cfg.baudrate      = 115200U;
	uart_cfg.data_bits     = 8U;
	uart_cfg.frame_length  = 8U;
	uart_cfg.stop_bits     = 1U;
	uart_cfg.oversampling  = 16U;
	uart_cfg.parity_mode   = XMC_USIC_CH_PARITY_MODE_NONE;
	XMC_UART_CH_Init(XMC_UART1_CH1,&uart_cfg);
	
	/*Set input source path*/
	XMC_UART_CH_SetInputSource(XMC_UART1_CH1, XMC_UART_CH_INPUT_RXD, USIC1_C1_DX0_P0_0);
	/*Configure transmit FIFO*/
	XMC_USIC_CH_TXFIFO_Configure(XMC_UART1_CH1,48U,XMC_USIC_CH_FIFO_SIZE_16WORDS,1U);
	/*Configure receive FIFO*/
	XMC_USIC_CH_RXFIFO_Configure(XMC_UART1_CH1,32U,XMC_USIC_CH_FIFO_SIZE_16WORDS,15U);
	/* Start UART */
	XMC_UART_CH_Start(XMC_UART1_CH1);

	/*Set service request for UART protocol events*/
	XMC_USIC_CH_SetInterruptNodePointer(XMC_UART1_CH1, XMC_USIC_CH_INTERRUPT_NODE_POINTER_PROTOCOL,2U);
	/*Set service request for rx FIFO receive interrupt*/
	XMC_USIC_CH_RXFIFO_SetInterruptNodePointer(XMC_UART1_CH1, XMC_USIC_CH_RXFIFO_INTERRUPT_NODE_POINTER_STANDARD,0x0U);
	/*Enable UART receive event*/
	XMC_USIC_CH_RXFIFO_EnableEvent(XMC_UART1_CH1, XMC_USIC_CH_RXFIFO_EVENT_CONF_STANDARD);
	
	daisyChainGPIOInit();
}

/****************************
*
*	����ͨ�����ݴ��
*
*****************************/
void daisyChainSendData(uint8_t command,uint16_t data1,uint16_t data2,uint16_t data3,uint16_t data4)
{
	DaisyTransmit[0] = command;
	DaisyTransmit[1] = (uint8_t)(data1>>8);
	DaisyTransmit[2] = (uint8_t)data1;
	
	DaisyTransmit[3] = command;
	DaisyTransmit[4] = (uint8_t)(data2>>8);
	DaisyTransmit[5] = (uint8_t)data2;
	
	DaisyTransmit[6] = command;
	DaisyTransmit[7] = (uint8_t)(data3>>8);
	DaisyTransmit[8] = (uint8_t)data3;
	
	DaisyTransmit[9] = command;
	DaisyTransmit[10] = (uint8_t)(data4>>8);
	DaisyTransmit[11] = (uint8_t)data4;
	
	DaisyTransmit[12] = DAISY_STOP_BYTE;
	
	for(uint8_t i = 0;i < DAISY_BUFFER_SIZE;i++){
		while(XMC_USIC_CH_TXFIFO_IsFull(XMC_UART1_CH1)){
			XMC_UART_CH_Transmit(XMC_UART1_CH1,DaisyTransmit[i]);
		}
	}
}

/***************************************
*
*	��������4�������������[1000,2000]
*
***************************************/
void daisyChainSetMotors(uint16_t motor1,uint16_t motor2,uint16_t motor3,uint16_t motor4)
{
	speedval1 = (uint16_t)((motor1 - 1000)/1000.0f*65535.0f);		//65535.0f for PINUS Software V2.0, 1279.0f for Old PINUS Software
	speedval2 = (uint16_t)((motor2 - 1000)/1000.0f*65535.0f);
	speedval3 = (uint16_t)((motor3 - 1000)/1000.0f*65535.0f);
	speedval4 = (uint16_t)((motor4 - 1000)/1000.0f*65535.0f);	
	
	daisyChainSendData(SET_REF_SPEED,speedval1,speedval2,speedval3,speedval4);
}
